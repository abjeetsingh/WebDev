// THE BELOW CODE DOESNT WORK
//Now it works - It's better to not to do css manipulation in JS because it is expensive
//read: https://www.learnsteps.com/javascript-understanding-repaint-and-reflow-of-dom-for-increasing-performance/

const navBar = document.getElementById('nav-bar');
const openIcon = document.getElementById('open-icon');
const closeIcon = document.getElementById('close-icon');

openIcon.addEventListener("click", show);
closeIcon.addEventListener('click', hide);

function show(){
    navBar.classList.add('show');
    openIcon.classList.add('hide');
    closeIcon.classList.remove('hide');
}
function hide(){
    navBar.classList.remove('show');
    openIcon.classList.remove('hide');
    closeIcon.classList.add('hide');
}

//it was not working because you were placing script tag before the body
//JS is parser blocking resource so as soon as browser sees script tag it stops everything else and starts running it.
//if your html is not parsed beforehand and you have placed script on the top, it will not work since html body has not been parsed yet
// so if your html is anything to do with body elements place it in bottom
//read : https://bitsofco.de/understanding-the-critical-rendering-path/

const myButton = document.getElementById("myBtn");
window.onscroll = function() {scrollFunction()};
function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        myButton.style.display = "block";
    } else {
        myButton.style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}

// start of crousel
jQuery(document).ready(function($) {
    "use strict";
    //  TESTIMONIALS CAROUSEL HOOK
    $('#customers-testimonials').owlCarousel({
        loop: true,
        center: true,
        items: 3,
        margin: 0,
        autoplay: true,
        dots:true,
        autoplayTimeout: 3500,
        smartSpeed: 50,
        responsive: {
          0: {
            items: 1
          },
          800: {
            items: 2
          },
          1170: {
            items: 3
          }
        }
    });
  });
  
  
// send 